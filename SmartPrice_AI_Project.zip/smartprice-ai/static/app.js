const form = document.getElementById("pricingForm");
const demand = document.getElementById("demand");
const demandValue = document.getElementById("demandValue");
const emptyState = document.getElementById("emptyState");
const result = document.getElementById("result");
const errorBox = document.getElementById("error");

demand.addEventListener("input", () => demandValue.value = demand.value);

const money = value => new Intl.NumberFormat("en-IN", {
  style: "currency", currency: "INR", maximumFractionDigits: 2
}).format(value);

form.addEventListener("submit", async event => {
  event.preventDefault();
  errorBox.classList.add("hidden");
  const button = form.querySelector("button");
  button.disabled = true;
  button.textContent = "Calculating recommendation…";
  const values = Object.fromEntries(new FormData(form).entries());
  ["base_price","competitor_price","demand","stock","sales_velocity"].forEach(k => values[k] = Number(values[k]));
  try {
    const response = await fetch("/api/predict", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify(values)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not calculate price.");
    emptyState.classList.add("hidden");
    result.classList.remove("hidden");
    document.getElementById("recommendedPrice").textContent = money(data.recommended_price);
    document.getElementById("currentPrice").textContent = money(data.base_price);
    document.getElementById("suggestedPrice").textContent = money(data.recommended_price);
    document.getElementById("changePill").textContent = `${data.change > 0 ? "+" : ""}${data.change}%`;
    document.getElementById("changePill").classList.toggle("down", data.change < 0);
    document.getElementById("decision").textContent = data.decision;
    document.getElementById("reason").textContent = data.reason;
    document.getElementById("modelNote").textContent = `${data.model} · ${data.disclaimer}`;
    await loadHistory();
  } catch (error) {
    errorBox.textContent = error.message;
    errorBox.classList.remove("hidden");
  } finally {
    button.disabled = false;
    button.innerHTML = "<span>✦</span> Calculate smart price";
  }
});

async function loadHistory() {
  const body = document.getElementById("historyBody");
  try {
    const response = await fetch("/api/history");
    const items = await response.json();
    if (!items.length) {
      body.innerHTML = '<tr><td colspan="5" class="muted">No recommendations yet.</td></tr>';
      return;
    }
    body.innerHTML = items.slice(0, 8).map(item => `
      <tr>
        <td>${escapeHtml(item.product)}</td>
        <td>${money(item.base_price)}</td>
        <td>${money(item.recommended_price)}</td>
        <td>${item.change > 0 ? "+" : ""}${item.change}%</td>
        <td>${escapeHtml(item.decision)}</td>
      </tr>`).join("");
  } catch {
    body.innerHTML = '<tr><td colspan="5" class="muted">History is temporarily unavailable.</td></tr>';
  }
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}
document.getElementById("refreshBtn").addEventListener("click", loadHistory);
loadHistory();
